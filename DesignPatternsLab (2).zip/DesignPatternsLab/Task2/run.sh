#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p out
javac -encoding UTF-8 -d out src/task2/*.java
java -Duser.language=en -Duser.country=US -cp out task2.Main
