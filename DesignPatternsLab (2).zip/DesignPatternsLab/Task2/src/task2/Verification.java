package task2;

public class Verification {
    private static void check(boolean condition) {
        if (!condition) throw new AssertionError("Verification failed");
    }

    public static void main(String[] args) {
        final int[] calls = {0};
        StockProvider source = new StockProvider() {
            public double getMarketPrice(String ticker) { calls[0]++; return 42; }
            public String getStatus(String ticker) { return "OPEN"; }
        };
        StockProvider cached = new CachedStockProxy(source, 10000);
        check(cached.getMarketPrice("A") == 42);
        check(cached.getMarketPrice("A") == 42 && calls[0] == 1);
        StockProvider expired = new CachedStockProxy(source, 0);
        expired.getMarketPrice("A");
        expired.getMarketPrice("A");
        check(calls[0] == 3);
        StockProvider adapter = new StockFeedAdapter(new LegacyStockFeed());
        check(Math.abs(adapter.getMarketPrice("GOOGL") - 164.5) < 0.001);
        check(adapter.getStatus("missing").equals("UNKNOWN"));
        System.out.println("Task2 verification passed");
    }
}
