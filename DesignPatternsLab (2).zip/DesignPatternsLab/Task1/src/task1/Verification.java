package task1;

public class Verification {
    private static void check(boolean condition) {
        if (!condition) throw new AssertionError("Verification failed");
    }

    public static void main(String[] args) {
        String csv = new CsvFormatter().format("Test", new String[]{"Name"}, new String[][]{{"a,\"b"}});
        check(csv.contains("\"a,\"\"b\""));
        String json = new JsonFormatter().format("a\"b", new String[]{"x"}, new String[][]{{"line\n"}});
        check(json.contains("a\\\"b") && json.contains("line\\u000a"));
        final String[] result = new String[1];
        Exporter capture = (destination, data) -> result[0] = data;
        new Base64EncryptDecorator(capture).export("test", "Hello");
        check(result[0].equals("[BASE64_CIPHERTEXT:SGVsbG8=]"));
        new HeaderFooterDecorator(capture, "today").export("test", "data");
        check(result[0].contains("today") && result[0].contains("data"));
        System.out.println("Task1 verification passed");
    }
}
