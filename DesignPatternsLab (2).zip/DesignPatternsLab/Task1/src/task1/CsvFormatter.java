package task1;

public class CsvFormatter implements ReportFormatter {
    public String format(String title, String[] headers, String[][] rows) {
        StringBuilder result = new StringBuilder();
        result.append("# TITLE: ").append(title).append("\n");
        result.append(formatRow(headers));
        for (String[] row : rows) {
            result.append(formatRow(row));
        }
        return result.toString();
    }

    private String formatRow(String[] row) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < row.length; i++) {
            if (i > 0) result.append(",");
            result.append("\"").append(row[i].replace("\"", "\"\"")).append("\"");
        }
        return result.append("\n").toString();
    }
}
