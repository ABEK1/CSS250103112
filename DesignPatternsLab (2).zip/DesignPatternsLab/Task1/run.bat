@echo off
cd /d "%~dp0"
if not exist out mkdir out
javac -encoding UTF-8 -d out src\task1\*.java
if errorlevel 1 goto end
java -Duser.language=en -Duser.country=US -cp out task1.Main
:end
pause
