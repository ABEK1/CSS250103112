package task4;

public class Verification {
    private static void check(boolean condition) {
        if (!condition) throw new AssertionError("Verification failed");
    }

    public static void main(String[] args) {
        PricingService base = new CurrencyOrderAdapter(new LegacyForeignOrder("T", 100), new LegacyCurrencyConverter(), "USD");
        check(base.calculateTotal() == 125);
        PricingService complete = new CustomsDutyDecorator(new ExpressCourierDecorator(new GiftWrapDecorator(base)));
        check(Math.abs(complete.calculateTotal() - 157.33) < 0.001);
        check(complete.getReceiptBreakdown().contains("Gift Wrap"));
        PricingService otherOrder = new GiftWrapDecorator(new CustomsDutyDecorator(base));
        check(Math.abs(otherOrder.calculateTotal() - 140.63) < 0.001);
        System.out.println("Task4 verification passed");
    }
}
