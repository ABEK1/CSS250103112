Design Patterns Lab

Java 8 or newer. No external libraries.

Task1: Strategy and Decorator. JSON and CSV reports, metadata and Base64 encoding.
Task2: Adapter and Proxy. Legacy stock feed with a TTL price cache.
Task3: Bridge and Strategy. Email and SMS alerts with dispatch policies.
Task4: Adapter and Decorator. GBP to USD conversion and additional fees.
Task5: Bridge and Proxy. S3 and NFS storage with role checks.

Running on Windows

Extract the ZIP first. Open a task folder and double-click run.bat.
A JDK must be installed and java and javac must be available in PATH.

Running on Linux or macOS

Open a terminal in a task folder and run:

sh run.sh

VS Code

Open one task folder using File > Open Folder.
Open src/task1/Main.java for Task1 and click Run above main.
For Task2 open src/task2/Main.java, and similarly for the other tasks.
Each task has its own Main.java and runs independently.
The Java extension must be installed for the Run button to appear.

Manual example for Task1

javac -encoding UTF-8 -d out src/task1/*.java
java -Duser.language=en -Duser.country=US -cp out task1.Main

Notes

Each Main contains the corresponding verification scenario from the PDF, without comments.
Task1 follows the executable decorator order from the runner. Base64 runs first,
then HeaderFooter adds metadata. The PDF sample shows a different order and an
inconsistent payload length. The printed length is calculated from the real UTF-8 data.
Base64 is encoding, not encryption. The integrity label is simulated as in the lab.
Task2 cache ages depend on execution time. TTL starts after the upstream response.
Repeated price requests within the TTL use the cache. Status requests go upstream.
Task4 final total is 157.33 USD.
Task5 allows ADMIN, MEMBER and ENGINEER. Other roles are blocked.
Storage and file writing are simulated, as required in the lab.

Submission

The PDF also requires progressive Git commits and a push to your own repository.
Upload the extracted project there before submitting.

Verification

After running a task, run its checks from that task folder:

java -cp out task1.Verification

Replace task1 with task2, task3, task4 or task5 as needed.
