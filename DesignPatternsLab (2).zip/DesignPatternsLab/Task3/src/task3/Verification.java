package task3;

public class Verification {
    private static void check(boolean condition) {
        if (!condition) throw new AssertionError("Verification failed");
    }

    public static void main(String[] args) {
        DispatchStrategy policy = new BusinessHoursStrategy();
        check(!policy.shouldDispatch(1, 8));
        check(policy.shouldDispatch(1, 9));
        check(policy.shouldDispatch(1, 17));
        check(!policy.shouldDispatch(1, 18));
        check(policy.shouldDispatch(5, 2));
        check(new ImmediateStrategy().shouldDispatch(1, 23));
        final int[] sent = {0};
        MessageChannel channel = (recipient, message) -> sent[0]++;
        new DailySummaryAlert(channel, policy).processAlert("test", "data", 23);
        check(sent[0] == 0);
        new CriticalSystemAlert(channel, policy).processAlert("test", "data", 2);
        check(sent[0] == 1);
        System.out.println("Task3 verification passed");
    }
}
