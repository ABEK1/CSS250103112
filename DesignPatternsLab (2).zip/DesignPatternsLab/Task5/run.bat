@echo off
cd /d "%~dp0"
if not exist out mkdir out
javac -encoding UTF-8 -d out src\task5\*.java
if errorlevel 1 goto end
java -Duser.language=en -Duser.country=US -cp out task5.Main
:end
pause
