package task5;

public class Verification {
    private static void check(boolean condition) {
        if (!condition) throw new AssertionError("Verification failed");
    }

    public static void main(String[] args) {
        final int[] calls = {0};
        StorageDriver source = new StorageDriver() {
            public byte[] loadRawBlob(String path) { calls[0]++; return new byte[]{1}; }
            public String getStorageType() { return "TEST"; }
        };
        check(new StorageDriverProxy(source, new UserSession("guest", "GUEST")).loadRawBlob("x").length == 0);
        check(new StorageDriverProxy(source, new UserSession("unknown", "OTHER")).loadRawBlob("x").length == 0);
        check(calls[0] == 0);
        check(new StorageDriverProxy(source, new UserSession("member", "MEMBER")).loadRawBlob("x").length == 1);
        check(calls[0] == 1);
        System.out.println("Task5 verification passed");
    }
}
