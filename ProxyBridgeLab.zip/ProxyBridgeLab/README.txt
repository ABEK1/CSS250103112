Все 6 заданий выполнены в Main.java. В коде нет комментариев.

IntelliJ IDEA:
1. Создай Java-проект и выбери установленный JDK.
2. Скопируй Main.java в папку src.
3. Открой Main.java и нажми зелёную стрелку рядом с main.

Запуск через терминал из папки с Main.java:
javac Main.java
java Main

Задания 1-3: ProxyImage, ProxyVideo, SchoolProxyInternet.
Задания 4-5: SmartLight, AdvancedRemote, PartyRemote, Radio.
Задание 6: Weapon, Sword, MagicWand, Hero, Knight, Wizard.
